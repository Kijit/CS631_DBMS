<?php

session_start();
include_once"mysql_connect.php" ;
$clientid= $_SESSION['clientid'];
$prodid= $_POST['var'];

$query= mysql_query("SELECT FName FROM Client WHERE ClientID='$clientid'");
while($rows= mysql_fetch_array($query))
	{
		$fname=$rows['FName'];
	}
$query= mysql_query("INSERT INTO Cart (ClientID, Prod_id) VALUES ('$clientid', '$prodid')");
$sql= mysql_query($query) ;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Cart</title>
<style type="text/css">
a:link {
	color: #A00;
	text-decoration: underline;
}
a:visited {
	text-decoration: underline;
	color: #700;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: underline;
}
</style>
</head>

<body bgcolor="#BBBBBB" >
<article >
		<header align="center" >
<table width="100%">
  <tr>
    <th scope="col"><img src="header.jpg" width="1238" height="298" /></th>
  </tr>
</table>
<table width="100%">
  <tr>
    <td align="center">Your One stop solution to all IT needs !!</td>
    <td><a href="cart2.php">Go to Cart</a></td>
    <td>Welcome <?php echo"$fname" ?> !</td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="994" height="34">
  <tr>
    <th width="105" scope="row"><a href="home.html">Home</a></th>
    <th width="877" rowspan="6" scope="row"><table width="100%">
      <tr>
      <? 
	  $query= mysql_query("SELECT * FROM cart WHERE ClientID='$clientid'");
	  while($rows=mysql_fetch_array($query))
	  {
		  $prodid= $rows['Prod_id'];
		  $sql= mysql_query("SELECT * FROM Product WHERE Prod_id='$prodid'");
		while ($row= mysql_fetch_array($sql))
		{
			$name= $row['Name'];
			$description= $row['Description'];
			$price= $row['Price'];	
		}
		echo "$name $ $price <br>" ;
	  }
	  ?>
        
	 
      </tr>
    </table>
    
    </th>
  </tr>
  <tr>
    <th scope="row"><a href="desktop.php">Desktops</a></th>
    </tr>
  <tr>
    <th scope="row"><a href="laptop.php">Laptops</a></th>
    </tr>
  <tr>
    <th scope="row"><a href="printer.php">Printers</a></th>
    </tr>
  <tr>
    <th scope="row"><a href="accessory.php">Accessories</a></th>
    </tr>
  <tr>
    <th scope="row">&nbsp;</th>
    </tr>
</table>
<h1>&nbsp;</h1>
<p>&nbsp;</p>
  </header>
</article>
</body>
</html>
