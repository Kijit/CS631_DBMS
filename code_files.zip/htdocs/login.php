<?php
include_once"mysql_connect.php" ;

session_start();

$clientid= $_POST['ClientID'];
$password= $_POST['Password'];

if($clientid && $password)
{
	$query= mysql_query("SELECT * FROM CLient WHERE ClientID='$clientid' ");
	$numrows= mysql_num_rows($query);
	
	if($numrows!=0)
	{
		
		while($rows= mysql_fetch_array($query))
		{
			$dbusername= $rows['ClientID'];
			$dbpassword= $rows['Password'];
		}
		
		if($dbusername==$clientid && $dbpassword==$password)
		{
			echo " Login Succesful ! <a href='home.php'> Click here to start shopping </a> " ;
			$_SESSION['clientid']=$dbusername ;
		}
		
		
	}
	
	
	
	
}

?>