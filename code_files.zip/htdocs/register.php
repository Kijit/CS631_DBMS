<?php

include_once"mysql_connect.php" ;

session_start();

$clientid= $_POST['ClientID'];
$password= $_POST['Password'];
$fname= $_POST['FName'];
$lname= $_POST['LName'];
$email= $_POST['Email'];
$address= $_POST['Address'];
$phone= $_POST['PhoneNumber'];



$sql = "INSERT INTO Client (ClientID, FName, LName, Email, Password, Address, PhoneNumber, CreditLine, CreditStatus) VALUES ('$clientid', '$fname', '$lname', '$email', '$password', '$address', '$phone', '0', 'silver')";
$query= mysql_query($sql) or die;
?>