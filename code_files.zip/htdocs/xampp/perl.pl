#!/Applications/xampp/xamppfiles/bin/perl
print "Content-Type: text/html\n\n";

print "OK";
