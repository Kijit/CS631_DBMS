<?
	echo "OK";
	exit();
?>
NOK
